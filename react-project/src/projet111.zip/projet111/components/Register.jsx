import { useDispatch, useSelector } from 'react-redux'
import '../style.css'
import { useState } from 'react'
import { add, setCurrent } from '../redux/userSlice'
import { useNavigate } from 'react-router'
export const Register = () => {
  const users = useSelector(s => s.users.users)
  const dispach = useDispatch()
  const [user, setUser] = useState()
  const navigate = useNavigate()
  const check = () => {
    console.log(users);
    dispach(add(user))
    navigate('/Home')
    console.log(users);
  }
  return <>
  <div className="auth-page-container">
    <div className="form">

      <form className="signup-form" action="" method="post">
        <i className="fas fa-user-plus"></i>
        <input className="user-input" name="" placeholder="firstName" required onBlur={e => setUser({ ...user, firstName: e.target.value })}></input>
        <input className="user-input" name="" placeholder="lastName" required onBlur={e => setUser({ ...user, lastName: e.target.value })}></input>
        <input className="user-input" type="text" name="" placeholder="tz" required onBlur={e => setUser({ ...user, tz: e.target.value })}></input>
        <input className="user-input" type="password" name="" placeholder="Password" required onBlur={e => setUser({ ...user, password: e.target.value })}></input>
        <input onClick={check} className="btn" name="" value="SIGN UP"></input>
        {/* type='submit' */}
        <div className="options-02">
          <p>Already Registered? <a onClick={()=>navigate('/Login')}>Sign In</a></p>
        </div>
      </form>
    </div>
    </div>
  </>
}
<div className="auth-page-container"> 
            <div className="form">
                <form className="login-form" action="" method="post">
                    <i className="fas fa-user-circle"></i> 
                    <h2>כניסת משתמש</h2> {/* כותרת נוספת לעיצוב */}
                    <input className="user-input" type="text" name="" placeholder="שם משתמש" required onBlur={(e) => setUser({ ...user, firstName: e.target.value })}></input>
                    <input className="user-input" type="password" name="" placeholder="סיסמה" required onBlur={(e) => setUser({ ...user, password: e.target.value })}></input>
                    
                    <input onClick={checkUser} className="btn" type='button' value="כניסה"></input> {/* שינוי ל-type='button' למניעת ריענון */}
                    
                    <div className="options-02">
                        <a onClick={register}>עדיין לא רשום? צור חשבון</a>
                    </div>
                </form>
            </div>
        </div>