
// RequestDetails.js

import { useDispatch, useSelector } from "react-redux"
import { useLocation, useNavigate } from "react-router-dom"; // ** ייבוא useLocation **
import { allow, reject } from "../redux/requestSlice";
export const RequestDetails = () => {
    // קבלת אובייקט המיקום המכיל את ה-state שנשלח מ-ViewRequests
    const location = useLocation();
    const dispatch = useDispatch()
    const navigate=useNavigate()
    // שליפת ה-ID מתוך location.state
    const requestId = location.state?.id;

    // שליפת רשימת הבקשות המלאה מה-slice
    const asksList = useSelector(state => state.requests.asksList);

    // מציאת הבקשה הרלוונטית לפי ה-ID
    const currentRequest = asksList.find(x => x.id === requestId);

    // בדיקה לווידוא
    console.log("Request ID: ", requestId);
    console.log("currentRequest: ", currentRequest);

    if (!currentRequest) {
        // טיפול במקרה שלא נמצאה בקשה או שה-ID חסר
        return (
            <div style={{ padding: '20px', textAlign: 'center', color: '#dc3545' }}>
                <h2>❌ שגיאה: פרטי הבקשה לא נמצאו.</h2>
                <p>אנא ודא שה-ID נשלח כראוי או שהבקשה קיימת במערכת.</p>
            </div>
        );
    }

    // הצגת פרטי הבקשה
    return (
        <div className="request-details-container">
            <h2>פרטי בקשה: {currentRequest.id}</h2>
            <p>סטטוס: <span className="status-badge">{currentRequest.status}</span></p>
            {/* דוגמה להצגת נתונים, יש לעצב כטבלה או כרטיסים */}
            <div className="detail-card">
                <h3>פרטים אישיים</h3>
                <p>מספר זהות: {currentRequest.personal.tz}</p>
                <p>שם מלא: {currentRequest.personal.firstName} {currentRequest.personal?.lastName}</p>
                <p>תאריך לידה: {currentRequest.personal.dateOfBirth}</p>
                <p>כתובת: {currentRequest.personal.adress}</p>
                <p>טלפון: {currentRequest.personal.phoneNumber}</p>
                <p>מייל: {currentRequest.personal.email}</p>

                {/* יש להמשיך להציג את שאר הנתונים (משפחה, קורס, בנק) */}
            </div>
            <div><h3>פרטי משפחה</h3>
                <p>שם האב: {currentRequest.family.fatherName}</p>
                <p>שם האם: {currentRequest.family.motherName}</p>
                <p>מספר הילדים: {currentRequest.family.numOfChildren}</p>
                <p>אחים מעל גיל 19: {currentRequest.family.siblings19Plus}</p></div>

            <div>  <h3>פרטי המגמה</h3>
                <p>שם המגמה: {currentRequest.course.course}</p>
                <p>שכר לימוד שנתי: {currentRequest.course.paymentLearn}</p>
                <p> מספר שנות לימוד: {currentRequest.course.years}</p></div>

            <div><h3>פרטי בנק</h3>
                <p>בעל החשבון: {currentRequest.bank.acountOwner}</p>
                <p>שם הבנק: {currentRequest.bank.bankName}</p>
                <p>מספר סניף: {currentRequest.bank.branchNum}</p>
                <p> מספר חשבון בנק: {currentRequest.bank.accountNum}</p></div>


            <button onClick={() => { dispatch(allow(currentRequest)) && navigate('/ViewRequests')}}>אישור</button>
            <button onClick={() => { dispatch(reject(currentRequest)) && navigate('/ViewRequests') }}>סרוב</button>


        </div>
    );
}