import { useNavigate } from 'react-router'
import { LayOut } from '../forms/LayOut'
import swal from 'sweetalert'
import { useSelector } from 'react-redux'
export const SendRequest = () => {
    const current = useSelector(state => state.users.current)
    const navigate= useNavigate()
    if(current.tz==null){
        swal('Oopps!','עליך תחילה להכנס להרשם', 'error')
         navigate('/Login')
    }
    return <>
        {current.tz==null || <LayOut></LayOut> }
          
        
    </>
}