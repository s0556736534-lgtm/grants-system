
import { useSelector } from "react-redux"
import { selectNotAllowed } from "../redux/requestSlice"
import swal from 'sweetalert'
import { useNavigate } from "react-router"
// import './AdminRequests.css' // ** שינוי 1: ייבוא קובץ CSS **

export const ViewRequests = () => {
    const allrequests = useSelector(selectNotAllowed)
    const current= useSelector(s=>s.users.current)
    const navigate= useNavigate()
    // בדיקת הרשאות
    if(!current || !current.isManager){
        swal('','!!!!!תוכן זה חסוי', 'error')
        navigate('/Home')
        return null; // חשוב להחזיר null כדי לא לרנדר את התוכן של המנהל
    }
    
    // הצגת התוכן למנהל
    console.log("allrequests :", allrequests);
    const showReqests = (id) => { // שיניתי את e ל-id לשם בהירות
        navigate(`/RequestDetails`,{state: {id: id}}) // השתמש ב-navigate
    }
    return (
        <div className="admin-requests-container"> {/* ** שינוי 2: עוטף ראשי ** */}
            <h2>📜 בקשות פתוחות לטיפול מנהל</h2>
            
            {allrequests.length === 0 ? (
                <p className="no-requests">אין בקשות פתוחות לטיפול כרגע.</p>
            ) : (
                <table className="requests-table"> {/* ** שינוי 3: מחלקת טבלה ** */}
                    <thead> {/* ** שינוי 4: כותרות עמודות ** */}
                        <tr>
                            <th>מזהה בקשה (ID)</th>
                            <th>סטטוס נוכחי</th>
                            <th>פעולה</th>
                        </tr>
                    </thead>
                    <tbody>
                        {allrequests.map((item, index) => (
                            <tr key={index}>
                                <td><span className="request-id">{item.id}</span></td>
                                <td>
                                    <span className={`status-badge status-${item.status.replace(/\s/g, '-')}`}>
                                        {item.status}
                                    </span>
                                </td>
                                <td>
                                    {/* ** שינוי 5: כפתור עדכון סטטוס ** */}
                                    <button 
                                        onClick={() => showReqests(item.id)} 
                                        className="action-btn"
                                    >
                                        עדכן סטטוס
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    )
}