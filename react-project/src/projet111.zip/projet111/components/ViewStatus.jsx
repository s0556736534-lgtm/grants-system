import { useSelector } from 'react-redux'
import { useNavigate } from 'react-router'
import swal from 'sweetalert'
export const ViewStatus = () => {
    const current = useSelector(state => state.users.current)
    const allrequests = useSelector(state => state.requests.asksList)
    const navigate= useNavigate()
    if(current?.tz==null){
        swal('','עליך תחילה להכנס להרשם', 'error')
        navigate('/Login')
    }
    // if(allrequests.length>0){
    console.log("current");
    console.log(current);
    console.log("allrequests");
    console.log(allrequests);

    const currentRequests = allrequests?.filter(x => x.personal.tz === current.tz);
    console.log("currentRequests");
    console.log(currentRequests);
    if(currentRequests.length==0){
        swal('','לא קיים בקשה למשתמש זה','error')
        navigate('/Home')
    }
    const lastRequest=allrequests[allrequests?.length-1].status
    console.log(lastRequest);
    
    return <>
        {  
            currentRequests.length>0 && lastRequest=="waiting" && <h1>הבקשה שלך עדיין ממתינה לבדיקה</h1>||
            currentRequests.length>0 && lastRequest=="allow"  && <h1>!!!!!הבקשה שלך אושרה </h1>||
            currentRequests.length>0 && lastRequest=="reject" && <h1>.מצטערים הבקשה שלך נדחתה</h1>
        }
    </>
}