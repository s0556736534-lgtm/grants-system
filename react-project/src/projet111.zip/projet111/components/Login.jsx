import { useDispatch, useSelector } from "react-redux"
import { useNavigate } from 'react-router'
import { setCurrent } from '../redux/userSlice'
import { useState } from "react"
export const Login = () => {
    const users = useSelector(state => state.users.users)
    //console.log(users);

    const navigate = useNavigate()
    const [user, setUser] = useState()
    const dispach = useDispatch()
    const current = useSelector(state => state.users.current)

    const checkUser = () => {
        let flag = true
        users.forEach(x => {
            if (x.firstName == user.firstName && x.password == user.password && flag) {
                dispach(setCurrent(x))
                flag = false
                navigate('/Home')
            }
        });
        console.log("current: ", current);

        if (flag)
            navigate('/Register')
    }
    const register = () => {
        navigate('/Register')
    }
    return <>
        <div className="auth-page-container"> 
            <div className="form">
                <form className="login-form" action="" method="post">
                    <i className="fas fa-user-circle"></i> 
                    <h2>כניסת משתמש</h2> {/* כותרת נוספת לעיצוב */}
                    <input className="user-input" type="text" name="" placeholder="שם משתמש" required onBlur={(e) => setUser({ ...user, firstName: e.target.value })}></input>
                    <input className="user-input" type="password" name="" placeholder="סיסמה" required onBlur={(e) => setUser({ ...user, password: e.target.value })}></input>
                    
                    <input onClick={checkUser} className="btn" type='button' value="כניסה"></input> {/* שינוי ל-type='button' למניעת ריענון */}
                    
                    <div className="options-02">
                        <a onClick={register}>עדיין לא רשום? צור חשבון</a>
                    </div>
                </form>
            </div>
        </div>
    </>
}
