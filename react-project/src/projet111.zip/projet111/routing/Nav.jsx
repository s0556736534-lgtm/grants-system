import { NavLink } from "react-router"
import { useSelector } from "react-redux"
import '../style.css'
export const Nav = () => {
    const c=useSelector(s=>s.users.current)
    return <>
        <div className={'div'}>
            <h1>{c.firstName} שלום</h1>
            <NavLink to='Home' className='link'>דף בית</NavLink>
            <NavLink to='Login' className='link'>כניסה</NavLink>
            <NavLink to='Register' className='link'>הרשמה</NavLink>

            {/* <NavLink to='SendRequest' className='link'> הגשת בקשה למענק</NavLink> */}
            {
                c.isManager?
                    <NavLink to='ViewRequests' className='link'>הצגת הבקשות</NavLink>
                :
                    null
            }
            {/* {c?
                <NavLink to='ViewStatus' className='link'>צפיה בסטטוס</NavLink>
            :
                null} */}
        </div>
    </>
}