import { createSlice } from "@reduxjs/toolkit"
import swal from 'sweetalert'
const state = {
    current: {},
    users: [
        { tz: "123456", firstName: "manager", lastName: "a", password: "111", isManager: true },
        { tz: "12", firstName: "aa", lastName: "z", password: "222", isManager: false },
        { tz: "456", firstName: "", lastName: "", password: "333", isManager: false },
        { tz: "444", firstName: "p", lastName: "", password: "444", isManager: false },
        { tz: "555", firstName: "", lastName: "", password: "555", isManager: false },
        { tz: "0", firstName: "0", lastName: "dsf", password: "0", isManager: false }

    ]
}
const usesrsSlice = createSlice({
    name: "users",
    initialState: state,
    reducers: {
        add: (state, action) => {
            console.log("add start");
            console.log(state.users);
            console.log(action.payload);
            let flag = true
            state.users.forEach((i) => {
                //console.log("i: ",i);

                if (action.payload.tz === i.tz && flag) {

                    swal(`Hello ${i.firstName}`, 'you are here already', 'error')
                    console.log("if");
                    flag = false
                }
            })
            if (flag) {
                swal(`Hello ${action.payload.firstName}`, 'Login successed', 'success')
                console.log("else");
                action.payload.isManager = false
                state.users.push(action.payload);
                console.log("s ", state.current);
                console.log("u ", action.payload);
                state.current = action.payload
            }

            //debugger
        },
        setCurrent: (state, action) => {
            state.current = action.payload
        }

    }
})
console.log(state.users);

export const { add, setCurrent } = usesrsSlice.actions
export default usesrsSlice.reducer