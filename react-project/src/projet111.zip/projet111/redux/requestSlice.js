import { createSlice } from "@reduxjs/toolkit"
const state = {
    asksList: [{
        personal: {tz: "12", firstName:"svdkln"},
        family: {},
        course: {},
        bank: {},
        id: "0",
        status: "reject"

    }],
    count: 0,
    current: {
        // personal: {},
        // family: {},
        // course: {},
        // bank: {},
        // id: "0",
        // status: "waiting"

    }

}
const requestSlice = createSlice({
    name: "requests",
    initialState: state,
    reducers: {
        update: (state, action) => {
            const { typeForm, data } = action.payload
            state.current[typeForm] = {
                ...state.current[typeForm], ...data
            }
        },
        add: (state ,action) => {
            state.count++
            state.asksList.push(state.current)
            state.current= {
                personal: {},
                family: {},
                course: {},
                bank: {},
                id: state.count.toString(),
                status: "waiting"
           }
           
           
        },
        allow: (state, action) => {
            const l = state.asksList.find(x => x.id === action.payload.id.toString())
            if (l != null)
                l.status = "allow"

            console.log('allow');
            
        },
        reject: (state, action) => {
            const l = state.asksList.find(x => x.id === action.payload.id.toString())
            if (l != null)
               l.status = "reject"
        },
        // personal: (state, action) => {
        //     // כאן נשמור את הנתונים שנשלחו מהטופס
        //     state.personal = { ...state.personal, ...action.payload };
        // },
        // family: (state, action) => {
        //     state.family = { ...state.family, ...action.payload };
        // },
        // course: (state, action) => {
        //     state.course = { ...state.course, ...action.payload };
        // },
        // bank: (state, action) => {
        //     state.bank = { ...state.bank, ...action.payload };
        // }
    }
})
export const selectNotAllowed = state => state.requests.asksList.filter(x => x.status !== "allow") || []
export const { add, allow, reject,update } = requestSlice.actions //, bank, course, family,personal
export default requestSlice.reducer