import { useState, useEffect} from "react"
import { useDispatch, useSelector } from "react-redux"
import { update } from "../redux/requestSlice"

export const PersonalDetails=()=>{
    const [personalDetails, setPersonalDetails] = useState({})
    const [errors, setErrors] = useState({})
   const currentPersonal= useSelector(state => state.requests.current.personal)
   const count = useSelector(state=> state.requests.count)
   const dispatch = useDispatch()
   const [personal, setPersonal]= useState({
    tz: "",
    firstName: "",
    lastName: "",
    dateOfBirth: "",
    adress: "",
    phoneNumber: "",
    email: ""
   })

   useEffect(() => {
        if(currentPersonal)
            // && count>0
            setPersonal({...currentPersonal})
    //אם אין – לא נוגע בטופס, ישאר ריק
   },[currentPersonal])

   const sendPersonal=()=>{
    checkId()
    //אפשר להעלות קאונט פה
    dispatch(update({typeForm: "personal",data: personal}))
    console.log(currentPersonal);
    const checkId = () => {
        // אם אורך לא תקין
        const value=personal.tz
        if (value.length !== 9 || isNaN(value)) {  // Make sure ID is formatted properly
            // שגיאה
            setErrors({ ...errors, id: 'id length is too short!' })
            // ריקון ערך מ.ז
            setPersonalDetails({ ...personalDetails, id: '' })
        }
        else {
            let sum = 0, incNum;
            for (let i = 0; i < value.length; i++) {
                incNum = Number(value[i]) * ((i % 2) + 1);  // Multiply number by 1 or 2
                sum += (incNum > 9) ? incNum - 9 : incNum;  // Sum the digits up and add to total
            }
            if (sum % 10 !== 0) {
                // שגיאה של תקינות מ.ז
                setErrors({ ...errors, id: 'invalid id!' })
                // ריקון ערך מ.ז
                setPersonalDetails({ ...personalDetails, id: '' })
            }
            else {
                // מ.ז תקין
                // ריקון שגיאה
                setErrors({ ...errors, id: '' })
                // הצבת מ.ז
                setPersonalDetails({ ...personalDetails, id: value })
                
            }
        }

    }
   }
   return<>
    <h5>תעודת זהות</h5>
    <input value={personal.tz} onChange={e => {setPersonal({...personal,tz: e.target.value})}}/>
    <h5>שם פרטי</h5>
    <input value={personal.firstName} onChange={e => {setPersonal({...personal,firstName: e.target.value})}}/>
    <h5>שם משפחה</h5>
    <input value={personal.lastName} onChange={e => {setPersonal({...personal,lastName: e.target.value})}}/>
    <h5>תאריך לידה</h5>
    <input type="date" value={personal.dateOfBirth} onChange={e => {setPersonal({...personal,dateOfBirth: e.target.value})}}/>
    <h5>כתובת</h5>
    <input value={personal.adress} onChange={e => {setPersonal({...personal,adress: e.target.value})}}/>
    <h5>טלפון</h5>
    <input value={personal.phoneNumber} onChange={e => {setPersonal({...personal,phoneNumber: e.target.value})}}/>
    <h5>אימייל</h5>
    <input value={personal.email} onChange={e => {setPersonal({...personal,email: e.target.value})}}/>
    <br></br><button onClick={sendPersonal}>אישור</button>
    {/* {
        personal.tz.length!=9 && <h5>מספר זהות אינו תקין</h5>&&
        personal.firstName.length <=1 && <h5>שם פרטי מידי קצר</h5>&&
        personal.lastName.length <=1 && <h5>שם משפחה מידי קצר</h5>&&
        personal.phoneNumber.length < 9 || personal.phoneNumber.length > 10 && <h5>מספר הטלפון לא תקין</h5>
        //!personal.email.contain("@") || personal.email.contain("[א-ת]") && <h5>מייל לא תקין</h5>
    } */}
</>
}