import { useState, useEffect} from "react"
import { useDispatch, useSelector } from "react-redux"
import { update } from "../redux/requestSlice"
export const FamilyDetails=()=>{
   const currentFamily= useSelector(state => state.requests.current.family)
   const dispatch = useDispatch()
   const [family, setFamily]= useState({
    fatherName: "",
    motherName: "",
    numOfChildren: "",
    siblings19Plus: ""
   })

   useEffect(() => {
        if(currentFamily)
            setFamily({...currentFamily})
   },[currentFamily])

   const sendFamily=()=>{
    dispatch(update({typeForm: "family",data: family}))
    console.log(currentFamily);
    
   }
    return<>
    <h5>שמות ההורים</h5>
    <h5>שם האב</h5>
    <input value={family.fatherName} onChange={e=>{setFamily({...family,fatherName: e.target.value})}}/>
    <h5>שם האם</h5>
    <input value={family.motherName} onChange={e=>{setFamily({...family,motherName: e.target.value})}}/>
    <h5>כמות הילדים</h5>
    <input type="number" value={family.numOfChildren} onChange={e=>{setFamily({...family,numOfChildren: e.target.value})}}/>
    <h5>כמות אחים מעל גיל 19</h5>
    <input type="number" value={family.siblings19Plus} onChange={e=>{setFamily({...family,siblings19Plus: e.target.value})}}/>
    <br></br><button onClick={sendFamily}>אישור</button>
</>
}