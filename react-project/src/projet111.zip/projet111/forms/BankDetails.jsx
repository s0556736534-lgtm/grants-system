import { useState, useEffect} from "react"
import { useDispatch, useSelector } from "react-redux"
import { bank, update } from "../redux/requestSlice"
export const BankDetails=()=>{
    const currentBank= useSelector(state => state.requests.current.bank)
   const dispatch = useDispatch()
   const [bank, setBank]= useState({
    acountOwner: "",
    bankName: "",
    branchNum: "",
    accountNum: ""
   })
    useEffect(() => {
            if(currentBank)
                setBank({...currentBank})
       },[currentBank])
    
       const sendBank=()=>{
        dispatch(update({typeForm: "bank",data: bank}))
        console.log(currentBank);
        
       }
    return<>
    <h5>בעל חשבון</h5>
    <input value={bank.acountOwner} onChange={e=> {setBank({...bank, acountOwner: e.target.value})}}/>
    <h5>שם בנק</h5>
    <select value={bank.bankName} onChange={e=> {setBank({...bank, bankName: e.target.value})}}>
        <option disabled selected></option>
        <option>בנק מזרחי</option>
        <option>בנק הפועלים</option>
        <option>בנק הדואר</option>
        <option>בנק פאגי</option>
    </select>
    <h5>מספר סניף</h5>
    <input type="number" value={bank.branchNum} onChange={e=> {setBank({...bank, branchNum: e.target.value})}}/>
    <h5>מספר חשבון</h5>
    <input value={bank.accountNum} onChange={e=> {setBank({...bank, accountNum: e.target.value})}}/>
    <br></br><button onClick={sendBank}>אישור</button>
    </>
}