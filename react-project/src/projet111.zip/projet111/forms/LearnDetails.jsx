import { useState, useEffect} from "react"
import { useDispatch, useSelector } from "react-redux"
import { update } from "../redux/requestSlice"
export const LearnDetails=()=>{
   const currentCourse= useSelector(state => state.requests.current.course)
   const dispatch = useDispatch()
   const [course, setCourse]= useState({
    course: "",
    paymentLearn: "",
    years: ""
   })
    useEffect(() => {
            if(currentCourse)
                setCourse({...currentCourse})
       },[currentCourse])
    
       const sendCourse=()=>{
        dispatch(update({typeForm: "course",data: course}))
        console.log(currentCourse);
        
       }
    return<>
        <h5>מגמה</h5>
        <input value={course.course} onChange={e=>{setCourse({...course,course: e.target.value})}}/>
        <h5>שכר לימוד שנתי</h5>
        <input type="number" value={course.paymentLearn} onChange={e=>{setCourse({...course,paymentLearn: e.target.value})}}/>
        <h5>שנות לימוד</h5>
        <input type="number" value={course.years} onChange={e=>{setCourse({...course,years: e.target.value})}}/>
        <br></br><button onClick={sendCourse}>אישור</button>
    </>
}