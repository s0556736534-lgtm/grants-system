import { useDispatch, useSelector } from "react-redux"
import { add, update } from "../redux/requestSlice"
import { useNavigate } from "react-router"
export const Submit = () => {
    const dispatch = useDispatch()
    const navigate = useNavigate()
    const allrequests= useSelector(s=>s.requests.asksList)
    const current = useSelector(state => state.requests.current)
    const permit = () => {
        dispatch(add())
        navigate('/Home')
        console.log(allrequests);
    }
    const cancel = () => {
        dispatch(update({typeForm: "personal",data: {tz: "",firstName: "",lastName: "",dateOfBirth: "",adress: "",phoneNumber: "",email: ""}}))
        dispatch(update({typeForm: "family",data: {fatherName: "",motherName: "",numOfChildren: "",siblings19Plus: ""}}))
        dispatch(update({typeForm: "course",data: {course: "",paymentLearn: "",years: ""}}))
        dispatch(update({typeForm: "bank",data: {acountOwner: "",bankName: "",branchNum: "",accountNum: ""}}))
        navigate('/Home')
        console.log(current);
        
    }
    return <>
        <h2>האם הנך מאשר את שליחת הנתונים</h2>

        <button onClick={permit}>אישור</button>
        <button onClick={cancel}>ביטול</button>
    </>
}
// import { useState } from "react";

// export const Submit = ({ form }) => {
//   const [submitted, setSubmitted] = useState(false);

//   const handleSubmit = () => {
//     // כאן בדרך כלל תשלחי לשרת עם fetch או axios
//     console.log("שליחת נתונים:", form);

//     // סימולציה של שליחה מוצלחת
//     setSubmitted(true);
//   }

//   return <>
//     <h2>האם הנך מאשר את שליחת הנתונים?</h2>

//     <button onClick={handleSubmit}>אישור</button>
//     <button onClick={() => setSubmitted(false)}>ביטול</button>

//     {submitted && (
//       <div style={{ marginTop: "20px", backgroundColor: "#eef", padding: "10px" }}>
//         <h3>נתונים שנשלחו בהצלחה:</h3>
//         <pre>{JSON.stringify(form, null, 2)}</pre>
//       </div>
//     )}
//   </>
// }
